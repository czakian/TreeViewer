//pass in the root node
void foo::preorder(Node *tr){
  if (tr == NULL) {
    //if you want null nodes to be displayed you can keep this lines uncommented. 
    //it still works without them
    ////////////
    cout << "NULL" << endl;
    cout << endl;
    ///////////

    //do not comment out this one
    cout << endl;
  } else {
    cout << tr->root << endl;
    preorder(tr->left);
    preorder(tr->right);

  }
}
